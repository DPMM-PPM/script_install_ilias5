<?php
$id = 'usrto';
$version = '2.2.0';
$ilias_min_version = '5.3.0';
$ilias_max_version = '5.4.999';
$responsible = 'studer + raimann ag - Team Core';
$responsible_mail = 'support-core@studer-raimann.ch';
